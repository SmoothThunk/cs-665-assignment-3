
| CS-665       | Software Design & Patterns |
|--------------|----------------------------|
| Name         | Shriya Thakur              |
| Date         | 10/24/2023                 |
| Course       | Fall                       |
| Assignment # | 3                          |

# Assignment Overview
This project defines an implementation for an application that will automatically generate emails. Each email can be customized based on the customer type associated with it. 

# GitHub Repository Link:
https://github.com/SmoothThunk/cs-665-assignment-3

# Implementation Description 
The implementation of this project primarily relies on the `EmailGenerationTemplate` class which 
utilizes the `template method` design pattern to create a skeleton template that will create emails based on the algorithm setup in the `generateEmail` method. The template method functions by breaking down an algorithm into various steps (methods) that will then be executed in a specific order determined by how the main `template` method is implemented. 

Reviewing the `EmailGenerationTemplate` class, it is straightforward to follow the steps within the `generateEmail` method to gain a full understanding of how the `template method` design pattern works. 

The following methods will run each time the `generateEmail` method is called. 

`doHeader`: The header of the email will be printed. In this case, it is setup with a default header that all types of emails will use for this specific company. 

`doSubjectLine`: The subject line of the email will be printed. This method is left abstract given that each subject line should be unique based on the customer it is being emailed to. 

`doGreeting`: The greeting for the email is printed. A default greeting is setup in the event the company chooses not to create a unqiue one per each type of customer email. We allow the user to enter a unique name for the greeting. 

`doMessage`: The main body of the email is printed. This is left abstract as each message should be unique. 

`doPromotion`: A default promotion message is provided, this will only be used in specific customer emails. Notice we have boolean variables setup which allow us to identify what type of email we are generating, in the event that a `FrequentEmail` or `VipEmail` is being created, it is easy to check the status of the email being generated to optionally include the promotion with a conditional statement. This is only done once as an example, but can allow for further customization of emails if needed. 

`doSignature`: The signature for the email is printed. A default signature is setup in the event the company chooses not to create a unqiue one per each type of customer email. We allow the user to enter a unique name for the signature. 

To help simplify the project, instead of setting up specific classes to represent each customer type I chose to use an enumeration. The `CustomerType` then becomes a property included inside the generic email class itself which allows for easier addition of new customer types, and saves some time having to setup a new class per each type. Although, a unique customer email class needs to still be setup so correspond with each customer type being used. 

The main advantage of using the `template method` is that with each unique customer email template we want to create all we must do is create a new class which extends the generic `CustomerEmail` class and then override any of the methods in which we want to change the output of a specific part of the email. The `EmailGenerationTemplate` also makes it very easy to add new parts to the email and alter the main `template method`. 

The overall structure of this application is fairly flexible, and should make it easy for any company to design and generate new emails. 

# Maven Commands

We'll use Apache Maven to compile and run this project. You'll need to install Apache Maven (https://maven.apache.org/) on your system. 

Apache Maven is a build automation tool and a project management tool for Java-based projects. Maven provides a standardized way to build, package, and deploy Java applications.

Maven uses a Project Object Model (POM) file to manage the build process and its dependencies. The POM file contains information about the project, such as its dependencies, the build configuration, and the plugins used for building and packaging the project.

Maven provides a centralized repository for storing and accessing dependencies, which makes it easier to manage the dependencies of a project. It also provides a standardized way to build and deploy projects, which helps to ensure that builds are consistent and repeatable.

Maven also integrates with other development tools, such as IDEs and continuous integration systems, making it easier to use as part of a development workflow.

Maven provides a large number of plugins for various tasks, such as compiling code, running tests, generating reports, and creating JAR files. This makes it a versatile tool that can be used for many different types of Java projects.

## Compile
Type on the command line: 

```bash
mvn clean compile
```

## JUnit Tests
JUnit is a popular testing framework for Java. JUnit tests are automated tests that are written to verify that the behavior of a piece of code is as expected.

In JUnit, tests are written as methods within a test class. Each test method tests a specific aspect of the code and is annotated with the @Test annotation. JUnit provides a range of assertions that can be used to verify the behavior of the code being tested.

JUnit tests are executed automatically and the results of the tests are reported. This allows developers to quickly and easily check if their code is working as expected, and make any necessary changes to fix any issues that are found.

The use of JUnit tests is an important part of Test-Driven Development (TDD), where tests are written before the code they are testing is written. This helps to ensure that the code is written in a way that is easily testable and that all required functionality is covered by tests.

JUnit tests can be run as part of a continuous integration pipeline, where tests are automatically run every time changes are made to the code. This helps to catch any issues as soon as they are introduced, reducing the need for manual testing and making it easier to ensure that the code is always in a releasable state.

To run, use the following command:
```bash
mvn clean test
```

## Spotbugs 

SpotBugs is a static code analysis tool for Java that detects potential bugs in your code. It is an open-source tool that can be used as a standalone application or integrated into development tools such as Eclipse, IntelliJ, and Gradle.

SpotBugs performs an analysis of the bytecode generated from your Java source code and reports on any potential problems or issues that it finds. This includes things like null pointer exceptions, resource leaks, misused collections, and other common bugs.

The tool uses data flow analysis to examine the behavior of the code and detect issues that might not be immediately obvious from just reading the source code. SpotBugs is able to identify a wide range of issues and can be customized to meet the needs of your specific project.

Using SpotBugs can help to improve the quality and reliability of your code by catching potential bugs early in the development process. This can save time and effort in the long run by reducing the need for debugging and fixing issues later in the development cycle. SpotBugs can also help to ensure that your code is secure by identifying potential security vulnerabilities.

Use the following command:

```bash
mvn spotbugs:gui 
```

For more info see 
https://spotbugs.readthedocs.io/en/latest/maven.html

SpotBugs https://spotbugs.github.io/ is the spiritual successor of FindBugs.

## Checkstyle 

Checkstyle is a development tool for checking Java source code against a set of coding standards. It is an open-source tool that can be integrated into various integrated development environments (IDEs), such as Eclipse and IntelliJ, as well as build tools like Maven and Gradle.

Checkstyle performs static code analysis, which means it examines the source code without executing it, and reports on any issues or violations of the coding standards defined in its configuration. This includes issues like code style, code indentation, naming conventions, code structure, and many others.

By using Checkstyle, developers can ensure that their code adheres to a consistent style and follows best practices, making it easier for other developers to read and maintain. It can also help to identify potential issues before the code is actually run, reducing the risk of runtime errors or unexpected behavior.

Checkstyle is highly configurable and can be customized to fit the needs of your team or organization. It supports a wide range of coding standards and can be integrated with other tools, such as code coverage and automated testing tools, to create a comprehensive and automated software development process.

The following command will generate a report in HTML format that you can open in a web browser. 

```bash
mvn checkstyle:checkstyle
```

The HTML page will be found at the following location:
`target/site/checkstyle.html`




