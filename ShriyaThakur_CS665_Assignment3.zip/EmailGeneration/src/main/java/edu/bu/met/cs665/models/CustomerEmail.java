/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: CustomerEmail.java
 * Description: Abstract customer email class. Includes enumeration for customer types.
 */
package edu.bu.met.cs665.models;

public abstract class CustomerEmail extends EmailGenerationTemplate {

	public enum CustomerType {
		BUSINESS,
		RETURNING,
		FREQUENT,
		NEW,
		VIP 
	}
	
	CustomerType customerType;
	
	public CustomerEmail(CustomerType customerType) 
	{
		this.customerType = customerType;
		if (this.customerType.equals(CustomerType.BUSINESS)) {
			this.isBusiness = true;
		}
		if (this.customerType.equals(CustomerType.RETURNING)) {
			this.isReturning = true;
		}
		if (this.customerType.equals(CustomerType.FREQUENT)) {
			this.isFrequent = true;
		}
		if (this.customerType.equals(CustomerType.NEW)) {
			this.isNew = true;
		}
		if (this.customerType.equals(CustomerType.VIP)) {
			this.isVip = true;
		}
	}
	
}
