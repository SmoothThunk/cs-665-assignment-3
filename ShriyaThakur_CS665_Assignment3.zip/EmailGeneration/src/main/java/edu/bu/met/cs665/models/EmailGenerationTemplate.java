/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: EmailGenerationTemplate.java
 * Description: Utilizes template method, provides abstract methods for email generation.
 */
package edu.bu.met.cs665.models;

public abstract class EmailGenerationTemplate {
	
	public boolean isBusiness;
	public boolean isReturning;
	public boolean isFrequent;
	public boolean isNew;
	public boolean isVip;

	/**
	 * Works as template method, runs all methods to generate email. 
	 * @param recipientName name of email recipient
	 * @param senderName name of email sender
	 */
	public final void generateEmail(String recipientName, String senderName) {
		// Generates header of email.
		doHeader();
		// Generates subject line of email.
		doSubjectLine();
		// Generates greeting of email.
		doGreeting(recipientName);
		doMessage();
		if (isFrequent || isVip) {
			doPromotion();
		}
		doSignature(senderName);
	}

	public void doHeader() {
		System.out.println("The Rubber Duck Shop - Personalized Rubber Ducks for ALL Occasions!");
	}
	
	public abstract void doSubjectLine();
	
	public void doGreeting(String recipientName) {
		System.out.println("Greetings " + recipientName + ",");
	}
	
	public abstract void doMessage();
	
	public void doPromotion() {
		System.out.println("Thank you for being a loyal customer!");
		System.out.println("For a limited time save 50% your account renewal with promo code: ");
		System.out.println("DUCK2023");
	}
	
	public void doSignature(String senderName) {
		System.out.println("Sincerely,");
		System.out.println(senderName);
		System.out.println("Team Member @ The Rubber Duck Shop");
	}
	
}
