/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: BusinessEmail.java
 * Description: Overrides methods to generate business email.
 */
package edu.bu.met.cs665.models;

public class BusinessEmail extends CustomerEmail {

	public BusinessEmail() {
		super(CustomerType.BUSINESS);
	}

	@Override
	public void doSubjectLine() {
		System.out.println("Business Account Renewal");
	}

	@Override
	public void doMessage() {
		System.out.println("We are contacting you to notify you that your business account is due for renewal within 30 days from now.");
		System.out.println("If no payments are received by the end of this period your business account will be deactivated.");
	}

	@Override
	public void doSignature(String senderName) {
		System.out.println("Thanks for your support,");
		System.out.println(senderName);
		System.out.println("Team Member @ The Rubber Duck Shop");
	}

}
