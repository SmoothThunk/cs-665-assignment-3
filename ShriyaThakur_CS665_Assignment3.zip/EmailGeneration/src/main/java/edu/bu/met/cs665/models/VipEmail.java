/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: VipEmail.java
 * Description: Overrides methods to generate VIP email.
 */
package edu.bu.met.cs665.models;

public class VipEmail extends CustomerEmail {

	public VipEmail() {
		super(CustomerType.VIP);
	}

	@Override
	public void doSubjectLine() {
		System.out.println("VIP Monthly Update");
	}

	@Override
	public void doMessage() {
		System.out.println("This is our monthly update email to keep you informed on all the up-to-date rubber duck news: ");
		System.out.println("-> President Biden has recently signed off on a new policy to increase funding to help protect rubber duck habitats.");
		System.out.println("-> Rubber duck stocks have been sky rocketing, increasing by 10% within the last 3 months!");
		System.out.println("-> 10 new rubber duck shops have opened near you! View your account portal on our website for more info!");
	}
	
	@Override
	public void doPromotion() {
		System.out.println("Now here is your monthly VIP perk!");
		System.out.println("Use the code below to get 75% off your next rubber duck purchase:");
		System.out.println("VERYIMPORTANTDUCK2023");
	}

}
