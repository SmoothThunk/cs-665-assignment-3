/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: FrequentEmail.java
 * Description: Overrides methods to generate frequent email.
 */
package edu.bu.met.cs665.models;

public class FrequentEmail extends CustomerEmail {

	public FrequentEmail() {
		super(CustomerType.FREQUENT);
	}

	@Override
	public void doSubjectLine() {
		System.out.println("Special Offer!!!");
	}

	@Override
	public void doMessage() {
		System.out.println("Hope you are having a lovely day! :)");
	}

}
