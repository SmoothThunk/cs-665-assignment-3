/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: NewEmail.java
 * Description: Overrides methods to generate new email.
 */
package edu.bu.met.cs665.models;

public class NewEmail extends CustomerEmail {

	public NewEmail() {
		super(CustomerType.NEW);
	}

	@Override
	public void doSubjectLine() {
		System.out.println("Welcome to The Rubber Duck Shop!");
	}

	@Override
	public void doMessage() {
		System.out.println("We are glad to have you onboard!");
		System.out.println("You should receive another email containing the confirmation link for your account.");
		System.out.println("Please be sure to verify your account by clicking that link, and feel free to reach out");
		System.out.println("if you have any other questions!");
	}

}
