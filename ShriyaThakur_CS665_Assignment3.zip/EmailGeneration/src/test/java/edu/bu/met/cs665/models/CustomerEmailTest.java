/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 10/24/2023
 * File Name: CustomerEmailTest.java
 * Description: Responsible for testing output of each email object.
 */
package edu.bu.met.cs665.models;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CustomerEmailTest {

	// Setup new output stream.
	private final ByteArrayOutputStream outStream = new ByteArrayOutputStream();
	// Save initial print stream being used.
	private final PrintStream initOut = System.out;
	
	private BusinessEmail businessEmail;
	private ReturningEmail returningEmail;
	private FrequentEmail freqEmail;
	private NewEmail newEmail;
	private VipEmail vipEmail;
	
	private final String customer = "Stefan Salvatore";
	private final String employee = "Elena Gilbert";
	
	@Before
	public void setUp() throws Exception {
		// Set new stream to standard output.
		// Used to read print statements in tests.
		System.setOut(new PrintStream(outStream));
		
		businessEmail = new BusinessEmail();
		freqEmail = new FrequentEmail();
		returningEmail = new ReturningEmail();
		newEmail = new NewEmail();
		vipEmail = new VipEmail();
	}

	@Test
	public void testGenerateEmail_BusinessEmail() {
	
		String expectedEmail = "The Rubber Duck Shop - Personalized Rubber Ducks for ALL Occasions!\r\n"
				+ "Business Account Renewal\r\n"
				+ "Greetings Stefan Salvatore,\r\n"
				+ "We are contacting you to notify you that your business account is due for renewal within 30 days from now.\r\n"
				+ "If no payments are received by the end of this period your business account will be deactivated.\r\n"
				+ "Thanks for your support,\r\n"
				+ "Elena Gilbert\r\n"
				+ "Team Member @ The Rubber Duck Shop\r\n";
		
		businessEmail.generateEmail(customer, employee);
		
		assertEquals(expectedEmail, outStream.toString());
	}
	
	@Test
	public void testGenerateEmail_FrequentEmail() {
	
		freqEmail.generateEmail(customer, employee);
		
		String expectedEmail = "The Rubber Duck Shop - Personalized Rubber Ducks for ALL Occasions!\r\n"
				+ "Special Offer!!!\r\n"
				+ "Greetings Stefan Salvatore,\r\n"
				+ "Hope you are having a lovely day! :)\r\n"
				+ "Thank you for being a loyal customer!\r\n"
				+ "For a limited time save 50% your account renewal with promo code: \r\n"
				+ "DUCK2023\r\n"
				+ "Sincerely,\r\n"
				+ "Elena Gilbert\r\n"
				+ "Team Member @ The Rubber Duck Shop\r\n";
		
		assertEquals(expectedEmail, outStream.toString());
	}
	
	@Test
	public void testGenerateEmail_ReturningEmail() {
	
		returningEmail.generateEmail(customer, employee);
		
		String expectedEmail = "The Rubber Duck Shop - Personalized Rubber Ducks for ALL Occasions!\r\n"
				+ "Welcome Back!\r\n"
				+ "Greetings Stefan Salvatore,\r\n"
				+ "It has been a while since you last logged in.\r\n"
				+ "Make sure to checkout our recent newsletter for up-to-date information on new rubber ducks in stock!\r\n"
				+ "Sincerely,\r\n"
				+ "Elena Gilbert\r\n"
				+ "Team Member @ The Rubber Duck Shop\r\n";
		
		assertEquals(expectedEmail, outStream.toString());
	}
	
	@Test
	public void testGenerateEmail_NewEmail() {
	
		newEmail.generateEmail(customer, employee);
		
		String expectedEmail = "The Rubber Duck Shop - Personalized Rubber Ducks for ALL Occasions!\r\n"
				+ "Welcome to The Rubber Duck Shop!\r\n"
				+ "Greetings Stefan Salvatore,\r\n"
				+ "We are glad to have you onboard!\r\n"
				+ "You should receive another email containing the confirmation link for your account.\r\n"
				+ "Please be sure to verify your account by clicking that link, and feel free to reach out\r\n"
				+ "if you have any other questions!\r\n"
				+ "Sincerely,\r\n"
				+ "Elena Gilbert\r\n"
				+ "Team Member @ The Rubber Duck Shop\r\n";
		
		assertEquals(expectedEmail, outStream.toString());
	}
	
	@Test
	public void testGenerateEmail_VipEmail() {
	
		vipEmail.generateEmail(customer, employee);
		
		String expectedEmail = "The Rubber Duck Shop - Personalized Rubber Ducks for ALL Occasions!\r\n"
				+ "VIP Monthly Update\r\n"
				+ "Greetings Stefan Salvatore,\r\n"
				+ "This is our monthly update email to keep you informed on all the up-to-date rubber duck news: \r\n"
				+ "-> President Biden has recently signed off on a new policy to increase funding to help protect rubber duck habitats.\r\n"
				+ "-> Rubber duck stocks have been sky rocketing, increasing by 10% within the last 3 months!\r\n"
				+ "-> 10 new rubber duck shops have opened near you! View your account portal on our website for more info!\r\n"
				+ "Now here is your monthly VIP perk!\r\n"
				+ "Use the code below to get 75% off your next rubber duck purchase:\r\n"
				+ "VERYIMPORTANTDUCK2023\r\n"
				+ "Sincerely,\r\n"
				+ "Elena Gilbert\r\n"
				+ "Team Member @ The Rubber Duck Shop\r\n";
		
		assertEquals(expectedEmail, outStream.toString());
	}
	
	@After
	public void resetStreams() {
		// Returns output stream to initial state before testing.
		System.setOut(initOut);
	}
	
	

}
